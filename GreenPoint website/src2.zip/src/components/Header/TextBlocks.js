export const items = [
    {
        label: 'בית',
        location: '/'
    }, {
        label: 'אודות',
        location: '/about'
    }, {
        label: 'יתרונות',
        location: '/advantages'
    }, {
        label: 'מוצרים',
        location: '/products',
        hash: ''
    }, {
        label: 'אפליקציה',
        location: '/apps',
    }, {
        label: 'שאלות נפוצות',
        location: '/faq'
    }, {
        label: 'צור קשר',
        location: '/contact'
    }
];
