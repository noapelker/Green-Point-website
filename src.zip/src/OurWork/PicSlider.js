import React from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import {Carousel} from 'react-responsive-carousel';
import './Carusel.css'
import {CaruselImages,ExplainHotel} from "./TextBlocks";
const PicSlider = (props) => {
    return (

        <div className={"caruselContainer"}>
            <div className={"picH"}>
            <a href={" "} className={'round-buttonExit'} onClick={e => {
                e.preventDefault();
                props.onClickExit(e);
            }}>
                X</a>
            <Carousel showArrows={true}>
                { CaruselImages[props.inde].map((item, index) =>

                    <div key={index} style={{height: '100%'}}>
                        <img src={'/images/' + item} alt={''} className={'imageHolderCar'}/>
                        <p className={"legend"}>Legend 1</p>
                    </div>)}
            </Carousel>
            <div className={"textContainer"}>
            <div className={"TitleExplain"}>{ExplainHotel[props.inde].title}</div>
            <div className={"textExplain"}>{ExplainHotel[props.inde].text}</div>
            </div>
            </div>
        </div>
    );
};

export default PicSlider;