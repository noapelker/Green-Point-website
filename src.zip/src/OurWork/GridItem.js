import React, {Component} from 'react';
import {Pictures} from "./TextBlocks";

class GridItem extends Component {
    constructor(props, context) {

        super(props, context);
        this.state = {

        };
    }

    OnClickGridPic = () => {

        this.props.onClickPic(this.props.inde);
    }
    render() {
        return (
            <div className={"GridItemContainer"} onClick={this.OnClickGridPic}>
                <img src={'/images/'+ Pictures[this.props.inde].image} alt={''} className={"GridItem"}/>
                <div className={"middle"}>
                    <div className={"textTitle"}>{this.props.deatils.textTitle}</div>
                    <div className={"text"}>{this.props.deatils.text}</div>

                </div>
            </div>
        );
    }
}

export default GridItem;