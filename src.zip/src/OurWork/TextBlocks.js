
export const Pictures = [
    {
        textTitle: 'מלון, פארק רויאל, לונדון',
        text: 'מרשת מלונות Park Plaza',
        image: 'ParkRoyal1.jpg'
    }, {
        textTitle: 'מלון ריברבנק, לונדון',
        text: 'מרשת מלונות Park Plaza',
        image: 'Riverbank1.jpg'
    }, {
        textTitle: 'מלון ויקטוריה, אמסטרדם',
        text: 'מרשת מלונות Park Plaza',
        image: 'VictoriaAmsterdam3.jpg'
    }, {
        textTitle: 'מלון ווטרלו, לונדון ',
        text: 'מרשת מלונות Park Plaza',
        image: 'WaterlooLondon1.jpg'
    }, {
        textTitle: 'מלון ויקטוריה, לונדון',
        text: 'מרשת מלונות Park Plaza',
        image: 'VictoriaLondon2.jpg'
    }, {
        textTitle: ' rent 24, תל אביב',
        text: 'השכרת משרדים',
        image: 'rent1.jpg'
    }
];
export const InProgress = [
    {
        title: 'רחוב המדע, רחובות',
        image: 'others1.jpg',
    }, {
        title: 'מגדלים בשדרה, רחובות',
        image: 'others2.jpg',
    }, {
        title: 'משכנות הלאום, ירושלים',
        image: 'others3.jpg',
    }, {
        title: 'פז כלכלה, הרצליה',
        image: 'others10.jpg',
    },{
        title: 'קאנטרי קלאב, אריאל',
        image: 'others9.jpg',
    }, {
        title: ' Vista, נתניה',
        image: 'others6.jpg',
    }
    , {
        title: 'טופ ארנונה, ירושלים',
        image: 'others7.jpg',
    }, {
        title: 'אדלטק, בני ברק',
        image: 'others12.jpg',
    }
    , {
        title: 'רשת Holmes place',
        image: 'others8.jpg',
    }, {
        title: ' Highline, רמת גן',
        image: 'others5.jpg',
    }, {
        title: 'חצרות המושבה, רחובות',
        image: 'others11.jpg',
    }, {
        title: '  Smart Towers, רמת גן ',
        image: 'others4.jpg',
    }


];
export const ExplainHotel = [
    {
        title: 'מלון, פארק רויאל, לונדון',
        text: '450 חדרים, כל האזורים הציבוריים כולל קומת קרקע וקבלה, חדרי ישיבות, מסעדות ומועדון.',
    }, {
        title: 'מלון ריברבנק, לונדון',
        text: '750 חדרים, כל האזורים הציבוריים כולל קומת קרקע וקבלה, 5 חדרי ישיבות, מסעדות ומועדון.',
    }, {
        title: 'מלון ויקטוריה, אמסטרדם',
        text: '350 חדרים, אזורים ציבוריים , חדרי ישיבות ומסעדות.',
    }, {
        title: 'מלון ווטרלו, לונדון',
        text: '500 חדרים, 56 חדרי ישיבות ומקומות ציבוריים כולל ספא, בריכה, קבלה, מסעדות ומזנונים. ',
    }, {
        title: 'מלון ויקטוריה, לונדון',
        text: '500 חדרים ומקומות ציבוריים כולל קומת קרקע וקבלה.',
    }, {
        title: 'Rent24',
        text: '50 משרדים, חדרי ישיבות, סלון ומועדון.',
    }
];

export const CaruselImages = [
    [
        'ParkRoyal1.jpg ',
        'ParkRoyal2.jpg',
        'ParkRoyal3.jpg',
        'ParkRoyal4.jpg',
        'ParkRoyal5.jpg',
        'ParkRoyal6.jpg'
    ], [
        'Riverbank1.jpg ',
        'Riverbank2.jpg',
        'Riverbank3.jpg',
        'Riverbank4.jpg',
        'Riverbank5.jpg',
    ], [
        'VictoriaAmsterdam3.jpg ',
        'VictoriaAmsterdam2.jpg',
        'VictoriaAmsterdam1.jpg',
        'VictoriaAmsterdam4.jpg',
        'VictoriaAmsterdam5.jpg'
    ], [
        'WaterlooLondon1.jpg ',
        'WaterlooLondon2.jpg',
        'WaterlooLondon3.jpg',
        'WaterlooLondon4.jpg',
        'WaterlooLondon5.jpg',
        'WaterlooLondon6.jpg'
    ], [
        'VictoriaLondon2.jpg',
        'VictoriaLondon3.jpg',
        'VictoriaLondon4.jpg',
        'VictoriaLondon5.jpg',
        'VictoriaLondon6.jpg'
    ], [
        'rent1.jpg',
        'rent2.jpg',
        'rent3.jpg',
        'rent4.jpg'
    ]
];