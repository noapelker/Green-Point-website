import React, {Component} from 'react';
import './OurWork.css';
import {Pictures,InProgress} from "./TextBlocks";
import GridItem from "./GridItem"
import PicSlider from "./PicSlider";

class OurWork extends Component {
    constructor(props, context) {
        super(props, context);
        this.state = {
            hidePictures: false,
            picIndex: 1,

        };
    }

    LargerPicture = (index) => {
        console.log(index);

        this.setState({picIndex: index, hidePictures: true});
    };
    OnClosePic = (target) => {
        if (target.target.className !== '' && target.target.className !== 'GridItem'
            && target.target.className !== 'control-arrow control-next' && target.target.className !== 'control-arrow control-prev'
            && target.target.className !== 'thumb' && target.target.className !== 'dot' && target.target.className !== 'control-dots')
            this.setState({hidePictures: false, picIndex: 0});

    };

    render() {
        return (
            <div onClick={this.OnClosePic} style={{
                width: '100%',
                height: 'fit-content',
                display: 'flex',
                flexDirection: 'column',
                backgroundColor: 'rgba(219, 227, 255, 0.15)',

            }}>
                <div className={"BackgroundTitle"} style={{}}><img src={'/images/logo.svg'} alt={''}
                                                                   className={"imgLogo"}/>

                </div>
                <div className={"textHolder"}>
                    <span className={"WorkTitle"}>הפרויקטים שלנו</span>
                    <span className={"WorkText"}>פרויקטים אחדים מכלל הפרויקטים ברחבי העולם בעלי מערכת הבית החכם של Green Point </span>

                </div>
                <div className={"container"} style={{position: 'relative'}}>
                    <div className={"GridContainer"}>
                        <div
                            className={"GridContainerRow"}> {Pictures.slice(0, 3).map((item, index) =>
                            <GridItem
                                key={index} deatils={item} inde={index}
                                onClickPic={this.LargerPicture}
                            />)} </div>
                        <div
                            className={"GridContainerRow"}> {Pictures.slice(3, 6).map((item, index) =>
                            <GridItem
                                key={index} deatils={item} inde={index + 3} onClickPic={this.LargerPicture}

                            />)} </div>


                    </div>
                    {this.state.hidePictures &&
                    <PicSlider inde={this.state.picIndex} onClickExit={this.OnClosePic}/>}


                </div>
                <div className={"othersHolder"}>
                    <div className={"titleOthers"}>פרויקטים נוספים</div>
                <div className={"rowOthers rowFirst"} >
                {InProgress.slice(0,6).map((item, index) =><div  key={index} style={{display:'flex',flexDirection:'column',width:'fit-content',maxWidth:'15%'}}> <div className={"textOthers"}>{InProgress[index].title}</div> <img
                    src={'/images/'+InProgress[index].image} alt={''} className={"othersPic"}/></div>
                )

                }

                </div>
                    <div className={"rowOthers"} >
                        {InProgress.slice(6,12).map((item, index) =><div  key={index} style={{display:'flex',flexDirection:'column',width:'fit-content',maxWidth:'15%'}}> <div className={"textOthers"}>{InProgress[index+6].title}</div> <img
                            src={'/images/'+InProgress[index+6].image} alt={''} className={"othersPic"}/></div>
                        )

                        }

                    </div>

            </div>
            </div>
        );
    }
}

export default OurWork;