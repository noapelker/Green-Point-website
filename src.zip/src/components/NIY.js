import React from 'react';

const NIY = () => {
    return (
        <h1 style={{marginTop: 300}}>
            NIY
        </h1>
    );
};

export default NIY;