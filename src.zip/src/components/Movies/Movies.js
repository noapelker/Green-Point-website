import React from 'react';
import './Movies.css';

const Movies = props => {
    return (
        <div style={{
            width: '100%',
            height: 'fit-content',
            display: 'flex',
            flexDirection: 'column',
            backgroundColor: 'rgba(219, 227, 255, 0.1)',

        }}>
            <div className={"BackgroundTitle"} style={{}}><img src={'/images/logo.svg'} alt={''}
                                                               className={"imgLogo"}/>
            </div>

            <div className={"textHolder"}>
                <span className={"Title "}>סרטים</span>
                <span className={"Text"}> </span>

            </div>
            <div className={"RowContainer"}>

                <iframe title={'IGH Product Introduction'}
                        className={"contain movie_frame"} style={{}}
                        allowFullScreen="allowfullscreen"
                        src="https://www.youtube.com/embed/w-2Khs6ftNc?autoplay=0"
                        frameBorder={0}


                >

                </iframe>
                <iframe title={'IGH Product Introduction'}
                        className={"contain movie_frame"} style={{}}
                        allowFullScreen="allowfullscreen"
                        src="https://www.youtube.com/embed/P1U-8Mgi-yw?autoplay=0"
                        frameBorder={0}


                >
                </iframe>

            </div>
        </div>
    );
};

export default Movies;